package com.example.musicviz

import android.content.Context
import android.graphics.Bitmap

/** Общее состояние для превью в приложении и диагностики. */
object Live {
    @Volatile var bmp: Bitmap? = null
    @Volatile var status = "Сервис не запущен"
}

/** Настройки (хранятся в SharedPreferences, сервис читает их на лету). */
class Cfg(c: Context) {
    private val p = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)
    var mode: Int
        get() = p.getInt("mode", 0)
        set(v) { p.edit().putInt("mode", v).apply() }
    var sens: Int
        get() = p.getInt("sens", 60)
        set(v) { p.edit().putInt("sens", v).apply() }
    var colorA: Int
        get() = p.getInt("a", 0xFF00E5FF.toInt())
        set(v) { p.edit().putInt("a", v).apply() }
    var colorB: Int
        get() = p.getInt("b", 0xFFFF4081.toInt())
        set(v) { p.edit().putInt("b", v).apply() }
    var source: Int
        get() = p.getInt("src", 0)
        set(v) { p.edit().putInt("src", v).apply() }
    var grad: Boolean
        get() = p.getBoolean("grad", true)
        set(v) { p.edit().putBoolean("grad", v).apply() }
}
