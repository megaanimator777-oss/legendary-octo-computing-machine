package com.example.musicviz

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class VisualizerWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        val rv = RemoteViews(c.packageName, R.layout.widget)
        // Нажатие на картинку: запуск/остановка. Нажатие на текст или фон: настройки.
        val toggle = PendingIntent.getForegroundService(c, 1,
            Intent(c, VisualizerService::class.java).setAction("toggle"), PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        rv.setOnClickPendingIntent(R.id.img, toggle)
        rv.setOnClickPendingIntent(R.id.title, open)
        rv.setOnClickPendingIntent(R.id.root, open)
        rv.setTextViewText(R.id.title, "Картинка — старт/стоп, текст — настройки")
        m.updateAppWidget(ids, rv)
    }
}
