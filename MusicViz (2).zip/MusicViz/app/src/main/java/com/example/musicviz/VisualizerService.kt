package com.example.musicviz

import android.app.*
import android.appwidget.AppWidgetManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.*
import android.media.*
import android.media.audiofx.Visualizer
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.IBinder
import android.os.PowerManager
import android.widget.RemoteViews
import kotlin.concurrent.thread
import kotlin.math.*

/**
 * Принцип как у Music VU: системный Visualizer (общий выход звука, любые плееры), без диалога записи экрана.
 * Работает, только пока экран включён и играет музыка (или выбран микрофон). Запасной вариант — микрофон.
 */
class VisualizerService : Service() {
    @Volatile private var viz: Visualizer? = null
    @Volatile private var mic: AudioRecord? = null
    @Volatile private var running = false
    @Volatile private var screenOn = true
    private var micFallback = false
    private var soundSeen = false
    private var lastSound = 0L
    private var title = ""
    private val cfg by lazy { Cfg(this) }
    private val screenRcv = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { screenOn = i.action == Intent.ACTION_SCREEN_ON }
    }

    companion object { const val N = 1024; const val BARS = 32; const val W = 480; const val H = 240 }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("viz", "Visualizer", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "viz").setContentTitle("Визуализатор работает")
            .setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true).build()
        try {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } catch (e: Exception) {
            Live.status = "Система не разрешила запуск (выдано ли разрешение на микрофон?): ${e.message}"
            stopSelf(); return START_NOT_STICKY
        }
        if (i?.action == "toggle" && running) { stopSelf(); return START_NOT_STICKY }
        if (!running) {
            running = true
            screenOn = getSystemService(PowerManager::class.java).isInteractive
            registerReceiver(screenRcv, IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_ON); addAction(Intent.ACTION_SCREEN_OFF)
            })
            thread { loop() }
        }
        return START_STICKY
    }

    private fun openViz() {
        viz = Visualizer(0).also { it.setEnabled(false); it.setCaptureSize(N); it.setEnabled(true) }
        soundSeen = false; lastSound = System.currentTimeMillis()
    }

    private fun openMic() {
        mic = AudioRecord(MediaRecorder.AudioSource.MIC, 44100, AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT, N * 4).also { it.startRecording() }
    }

    private fun close() {
        try { viz?.release() } catch (_: Exception) { }
        viz = null
        try { mic?.stop(); mic?.release() } catch (_: Exception) { }
        mic = null
    }

    private fun loop() {
        val mgr = AppWidgetManager.getInstance(this)
        val cn = ComponentName(this, VisualizerWidget::class.java)
        val am = getSystemService(AudioManager::class.java)
        val buf = ShortArray(N); val wb = ByteArray(N)
        val re = DoubleArray(N); val im = DoubleArray(N); val lv = FloatArray(BARS)
        var ids = mgr.getAppWidgetIds(cn)
        var last = 0L; var lastInfo = 0L; var lastMode = -1; var idleShown = false
        while (running) {
            try {
                val now = System.currentTimeMillis()
                val mode = cfg.source
                if (mode != lastMode) { close(); micFallback = false; lastMode = mode }
                val useMic = mode == 2 || (mode == 0 && micFallback)
                // Экономия батареи: экран выключен или музыка не играет — ничего не слушаем
                if (!screenOn || !(useMic || am.isMusicActive)) {
                    close()
                    Live.status = if (!screenOn) "Экран выключен — пауза" else "Музыка не играет — ожидание"
                    if (screenOn && !idleShown) {
                        ids = mgr.getAppWidgetIds(cn); lv.fill(0f)
                        val b = draw(lv); Live.bmp = b; push(mgr, ids, b, ""); idleShown = true
                    }
                    if (!screenOn) idleShown = false
                    Thread.sleep(400); continue
                }
                idleShown = false
                if (viz == null && mic == null) {
                    if (useMic) openMic() else try { openViz() } catch (e: Exception) {
                        if (mode == 0) { micFallback = true; continue } else throw e
                    }
                }
                val m = mic
                if (m != null) {
                    if (m.read(buf, 0, N) < N) { Thread.sleep(20); continue }
                    for (k in 0 until N) re[k] = buf[k] / 32768.0
                } else {
                    viz!!.getWaveForm(wb); Thread.sleep(30)
                    for (k in 0 until N) re[k] = ((wb[k].toInt() and 0xFF) - 128) / 128.0
                }
                var peak = 0.0
                for (k in 0 until N) { peak = max(peak, abs(re[k])); re[k] *= 0.5 - 0.5 * cos(2 * PI * k / (N - 1)); im[k] = 0.0 }
                if (peak > 0.001) { lastSound = now; soundSeen = true }
                else if (viz != null && mode == 0 && !soundSeen && now - lastSound > 3000) { micFallback = true; close(); continue }
                fft(re, im)
                val gain = 10.0.pow((cfg.sens - 50) / 50.0)
                for (b in 0 until BARS) {
                    val lo = 1 + 400.0.pow(b / BARS.toDouble()).toInt()
                    val hi = max(lo + 1, 1 + 400.0.pow((b + 1) / BARS.toDouble()).toInt())
                    var mg = 0.0
                    for (k in lo until hi) mg = max(mg, hypot(re[k], im[k]) / N * 4)
                    val lvl = ((20 * log10(mg * gain + 1e-6) + 70) / 60).toFloat().coerceIn(0f, 1f)
                    lv[b] = max(lvl, lv[b] * 0.85f)
                }
                if (now - last < 80) continue
                last = now
                if (now - lastInfo > 1000) {
                    lastInfo = now; ids = mgr.getAppWidgetIds(cn); title = track()
                    push(mgr, ids, null, title)
                    val src = if (mic != null) (if (mode == 0) "микрофон (запасной)" else "микрофон") else "системный Visualizer"
                    Live.status = "Источник: $src · уровень %.3f\nТрек: %s".format(peak, title.ifEmpty { "—" })
                }
                val bmp = draw(lv)
                Live.bmp = bmp
                push(mgr, ids, bmp, null)
            } catch (e: Exception) {
                Live.status = "Ошибка: ${e.javaClass.simpleName} ${e.message}"
                try { Thread.sleep(300) } catch (_: InterruptedException) { }
            }
        }
    }

    private fun push(mgr: AppWidgetManager, ids: IntArray, bmp: Bitmap?, title: String?) {
        if (ids.isEmpty()) return
        val rv = RemoteViews(packageName, R.layout.widget)
        bmp?.let { rv.setImageViewBitmap(R.id.img, it) }
        title?.let { rv.setTextViewText(R.id.title, it.ifEmpty { "Музыка не играет" }) }
        mgr.partiallyUpdateAppWidget(ids, rv)
    }

    private fun draw(lv: FloatArray): Bitmap {
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val a = cfg.colorA; val b = if (cfg.grad) cfg.colorB else a
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(0f, H.toFloat(), 0f, 0f, a, b, Shader.TileMode.CLAMP)
            strokeCap = Paint.Cap.ROUND
        }
        val bw = W / BARS.toFloat(); val hh = H.toFloat()
        when (cfg.mode) {
            0 -> for (i in 0 until BARS) {
                val h = max(6f, lv[i] * H)
                c.drawRoundRect(i * bw + 2, hh - h, (i + 1) * bw - 2, hh, 5f, 5f, p)
            }
            1 -> for (i in 0 until BARS) {
                val h = max(3f, lv[i] * H / 2)
                c.drawRoundRect(i * bw + 2, hh / 2 - h, (i + 1) * bw - 2, hh / 2 + h, 5f, 5f, p)
            }
            2 -> {
                val xs = FloatArray(BARS) { (it + .5f) * bw }
                val ys = FloatArray(BARS) { hh - max(4f, lv[it] * hh * .95f) }
                val path = Path().apply {
                    moveTo(xs[0], ys[0])
                    for (i in 1 until BARS) quadTo(xs[i - 1], ys[i - 1], (xs[i - 1] + xs[i]) / 2, (ys[i - 1] + ys[i]) / 2)
                    lineTo(xs[BARS - 1], ys[BARS - 1])
                }
                val fill = Path(path).apply { lineTo(xs[BARS - 1], hh); lineTo(xs[0], hh); close() }
                p.alpha = 90; c.drawPath(fill, p)
                p.alpha = 255; p.style = Paint.Style.STROKE; p.strokeWidth = 5f; c.drawPath(path, p)
            }
            else -> {
                val cx = W / 2f; val cy = hh / 2; val r0 = hh * .2f; val rl = hh * .28f
                p.style = Paint.Style.STROKE; p.strokeWidth = 6f
                val n = BARS * 2
                for (i in 0 until n) {
                    val k = if (i < BARS) i else n - 1 - i
                    val ang = i * 2 * PI / n - PI / 2
                    val r1 = r0 + max(3f, lv[k] * rl)
                    c.drawLine(cx + (r0 * cos(ang)).toFloat(), cy + (r0 * sin(ang)).toFloat(),
                        cx + (r1 * cos(ang)).toFloat(), cy + (r1 * sin(ang)).toFloat(), p)
                }
            }
        }
        return bmp
    }

    private fun track(): String = try {
        val ss = getSystemService(MediaSessionManager::class.java).getActiveSessions(ComponentName(this, NotifListener::class.java))
        val m = (ss.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING })?.metadata
        listOfNotNull(m?.getString(MediaMetadata.METADATA_KEY_ARTIST), m?.getString(MediaMetadata.METADATA_KEY_TITLE)).joinToString(" — ")
    } catch (e: SecurityException) { "Включите доступ к уведомлениям" }

    private fun fft(re: DoubleArray, im: DoubleArray) {
        val n = re.size; var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while ((j and bit) != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) { val t = re[i]; re[i] = re[j]; re[j] = t }
        }
        var len = 2
        while (len <= n) {
            val a = -2 * PI / len; val wr = cos(a); val wi = sin(a)
            var i = 0
            while (i < n) {
                var cr = 1.0; var ci = 0.0
                for (k in 0 until len / 2) {
                    val x = i + k; val y = x + len / 2
                    val tr = re[y] * cr - im[y] * ci; val ti = re[y] * ci + im[y] * cr
                    re[y] = re[x] - tr; im[y] = im[x] - ti; re[x] += tr; im[x] += ti
                    val t = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = t
                }
                i += len
            }
            len = len shl 1
        }
    }

    override fun onDestroy() {
        running = false
        try { unregisterReceiver(screenRcv) } catch (_: Exception) { }
        close()
        Live.status = "Сервис не запущен"
        super.onDestroy()
    }
}
